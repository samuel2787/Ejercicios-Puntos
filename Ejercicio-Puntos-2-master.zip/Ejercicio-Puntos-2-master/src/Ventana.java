import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JTextArea txtCodigo;
    private JButton butnComprobar;
    private JTextArea textImprimir;

    public Ventana() {
        butnComprobar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    Pila p = new Pila();
                    String codigo = txtCodigo.getText();
                    textImprimir.setText("");  // Limpiar antes de comenzar

                    for (int i = 0; i < codigo.length(); i++) {
                        char c = codigo.charAt(i);

                        if (c == '(' || c == '{' || c == '[') {
                            p.insertar(String.valueOf(c));
                            JOptionPane.showMessageDialog(null, "Se insertó: " + c);
                        } else if (c == ')' || c == '}' || c == ']') {
                            if (p.esVacia()) {
                                JOptionPane.showMessageDialog(null, "Código incorrecto: cierre sin apertura");
                                return;
                            }

                            char salida = p.extraer().charAt(0);
                            JOptionPane.showMessageDialog(null, "Se extrajo: " + salida);

                            if ((c == ')' && salida != '(') ||
                                    (c == '}' && salida != '{') ||
                                    (c == ']' && salida != '[')) {
                                JOptionPane.showMessageDialog(null, "Código incorrecto: no coincide " + salida + " con " + c);
                                return;
                            }
                        }

                        // Mostrar el estado actual de la pila
                        textImprimir.setText(p.toString());
                    }

                    if (p.esVacia()) {
                        JOptionPane.showMessageDialog(null, "Código correcto: todos los símbolos están con su cierre correcto.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Código incorrecto: quedaron símbolos sin cerrar.");
                    }

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
