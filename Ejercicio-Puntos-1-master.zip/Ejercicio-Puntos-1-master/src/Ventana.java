import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JLabel IblEtiqueta;
    private JTextField txtString;
    private JButton btnApilar;
    private JButton btnDesapilar;
    private JTextArea textArea1;
    private JPanel principal;
    private JButton btnPeek;
    private Pila lista = new Pila();

    public Ventana() {
        btnApilar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    lista.apilar(txtString.getText());
                    textArea1.setText(lista.toString());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });

        btnDesapilar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    String eliminado = lista.desapilar();
                    JOptionPane.showMessageDialog(null, "Eliminado:" + eliminado);
                    textArea1.setText(lista.toString());
                }catch (Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                    }
            }
        });
        btnPeek.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                String cima = lista.cima();
                JOptionPane.showMessageDialog(null, "El elemento que esta en la cima es "+cima);
            }catch (Exception ex)
            {
                JOptionPane.showMessageDialog(null,ex.getMessage());
            }
            }
        });
    }


    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
