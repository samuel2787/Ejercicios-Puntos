import java.util.Stack;

public class Pila {

    private Stack <String> arreglo;

    public Pila() {
        arreglo = new Stack<String>();
    }

    public void apilar(String dato) throws Exception {
        if (arreglo.size() >= 10) {
            throw new Exception("No se pueden añadir más de 10 elementos a la pila.");
        }
        arreglo.push(dato);
    }

    public String desapilar()throws Exception{
      if(arreglo.isEmpty())
          throw new Exception("Error al desapilar la fila que esta vacia");

      return arreglo.pop();
    }

    public String cima ()throws Exception{
        if(arreglo.isEmpty())
            throw new Exception("La pila esta vacia");

        return arreglo.peek();
    }

    @Override
    public String toString() {
        StringBuilder cadena = new StringBuilder();

        for(int indice = arreglo.size() - 1; indice>=0; indice --){
            cadena.append(arreglo.get(indice)+ "\n" );
        }
        return cadena.toString();
    }
}
